﻿using System;
using System.Windows.Forms;

using System.Net;
using System.IO;
using System.Diagnostics;

namespace RobloxShortcuts
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Length == 1)
            {
                PlayGame(args[0]);
            }
            else
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());
            }
        }

        private static HttpWebRequest GetRequest(Uri uri, CookieContainer cookies, string method)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
            //request.UserAgent = "Mozilla / 5.0(Windows NT 10.0; Win64; x64) AppleWebKit / 537.36(KHTML, like Gecko) Chrome / 74.0.3729.169 Safari / 537.36";
            request.CookieContainer = cookies;
            request.Method = method;
            request.ContentType = "application/json";
            request.ContentLength = 0;
            return request;
        }

        private static HttpWebResponse GetResponse(HttpWebRequest request)
        {
            HttpWebResponse response;

            //Ignore exception thrown by receiving a non-200 response
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException e)
            {
                response = (HttpWebResponse)e.Response;
            }

            return response;
        }

        private static void PlayGame(string placeId)
        {

            //Get exe directory
            string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location + "\\..";

            //Read login cookie from file
            StreamReader reader = new StreamReader(exePath + "\\loginCookie.txt");
            string cookieString = !reader.EndOfStream ? reader.ReadLine() : "";
            reader.Close();

            //Build cookie
            CookieContainer cookies = new CookieContainer();
            Cookie authCookie = new Cookie(".ROBLOSECURITY", cookieString);
            authCookie.Domain = ".roblox.com";
            cookies.Add(authCookie);

            //Get csrf token (needed to get auth ticket)
            HttpWebRequest request0 = GetRequest(new Uri("https://auth.roblox.com/"), cookies, "POST");
            HttpWebResponse response0 = GetResponse(request0);
            string csrfToken = response0.Headers.Get("X-CSRF-TOKEN");

            //Get authentication ticket
            HttpWebRequest request1 = GetRequest(new Uri("https://auth.roblox.com/v1/authentication-ticket/"), cookies, "POST");
            request1.Headers.Set("X-CSRF-TOKEN", csrfToken);
            request1.Referer = "https://www.roblox.com/";
            HttpWebResponse response1 = GetResponse(request1);
            string authTicket = response1.Headers.Get("rbx-authentication-ticket");

            //Check if authentication succeeded (if it didn't we probably didn't have the cookie or something went wrong)
            if (Array.IndexOf(response1.Headers.AllKeys, "rbx-authentication-ticket") == -1)
            {
                MessageBox.Show("Authentication failed, have you entered your cookie?");
                return;
            }

            //Build PlaceLaunch URL
            string placeLaunchUrl = "https://assetgame.roblox.com/game/PlaceLauncher.ashx?request=RequestGame&placeId=" + placeId;
            placeLaunchUrl = placeLaunchUrl.Replace(":", "%3A");
            placeLaunchUrl = placeLaunchUrl.Replace("/", "%2F");
            placeLaunchUrl = placeLaunchUrl.Replace("?", "%3F");
            placeLaunchUrl = placeLaunchUrl.Replace("=", "%3D");
            placeLaunchUrl = placeLaunchUrl.Replace("&", "%26");

            //Get launcher path
            string rbxFolder = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData) + "\\..\\Local\\Roblox\\Versions";
            string[] files = Directory.GetFiles(rbxFolder, "RobloxPlayerLauncher.exe", SearchOption.AllDirectories);
            string launcher = files[0];

            //Build command
            string command = "roblox-player:1+launchmode:play+gameinfo:";
            command += authTicket;
            command += "+placelauncherurl:";
            command += placeLaunchUrl;

            //Run launcher using command
            Process.Start(launcher, command);
        }
    }
}
