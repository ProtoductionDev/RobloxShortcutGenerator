﻿using System.Text.Json.Serialization;

namespace RobloxShortcuts
{
    public class ProductInfo
    {
        [JsonPropertyName("Name")]
        public string Name { get; set; }

        [JsonPropertyName("IconImageAssetId")]
        public long IconImageAssetId { get; set; }
    }
}
