﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RobloxShortcuts
{
    public partial class AuthForm : Form
    {

        private MainForm originalWindow;

        public AuthForm(MainForm main)
        {

            originalWindow = main;

            InitializeComponent();
            browser1.Navigate("https://www.roblox.com/Login");
        }

        private string GetAuthCookie()
        {
            return WebHelper.GetGlobalCookie("https://www.roblox.com/", ".ROBLOSECURITY");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string authCookie = GetAuthCookie();
            if (authCookie != null && authCookie.Contains(".ROBLOSECURITY="))
            {
                MessageBox.Show("Authentication successful!");

                //Get authCookie value
                authCookie = authCookie.Replace(".ROBLOSECURITY=", string.Empty);

                //Get exe path
                string exePath = System.Reflection.Assembly.GetExecutingAssembly().Location + "\\..";

                //Write login cookie to file
                StreamWriter writer = new StreamWriter(exePath + "\\loginCookie.txt");
                writer.Write(authCookie);
                writer.Close();

                //Close auth window
                this.Close();

            } else
            {
                MessageBox.Show("Authentication failed, are you logged in to an account?");
            }
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            originalWindow.Show();
        }
    }
}
